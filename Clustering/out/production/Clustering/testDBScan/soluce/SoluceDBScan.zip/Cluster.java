package testDBScan.soluce;

import javafx.scene.shape.Circle;

import java.util.TreeSet;

class Cluster
{
	/**data associated to the cluster*/
	private final TreeSet<Data> dataSet;
	/**nb of clusters*/
	private static int nb;
	/**no of the cluster*/
	int no;
	/**minimal distance between one of the data and the centroid
	 * */
	private double minDist;
	/**maximal distance between one of the data and the centroid
	 * */
	private double maxDist;
	/**average of the distances between the data and the centroid
	 * */
	private double moyDist;
	/**graphical representation*/
	Circle circle;

	public Cluster()
	{
		dataSet = new TreeSet<>();
		no = nb++;
		System.out.println("new cluster " + no);
	}


	/**add a data to the cluster (and tell to the data that it is associated to this cluster)*/
	public void add(Data data)
	{
		dataSet.add(data);
		data.setCluster(this);
	}

	/**remove a data to from the cluster 
	 * (and tell to the data that it is no more associated to this cluster)*/
	public void remove(Data data)
	{
		dataSet.remove(data);
		data.setCluster(null);
	}


	
	/**@return the no of the clusters, its nb of data, the stats and the data*/
	@Override
	public String toString()
	{
		StringBuilder sb = new StringBuilder("cluster " + no + ", nb elts =  " + dataSet.size() + "\n");
		int nb = Math.min(10, dataSet.size());
		Data[] tab = dataSet.toArray(Data[]::new);
		for(int i=0; i<nb; i++)
			sb.append(tab[i].toString()).append(" :: ");
		return sb.toString();
	}


	int getNo() {return no;}

}